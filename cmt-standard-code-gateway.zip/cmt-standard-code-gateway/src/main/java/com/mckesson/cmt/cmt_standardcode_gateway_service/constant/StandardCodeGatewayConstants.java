package com.mckesson.cmt.cmt_standardcode_gateway_service.constant;

public class StandardCodeGatewayConstants {
    public static final String SYSTEM = "SYSTEM";
}
