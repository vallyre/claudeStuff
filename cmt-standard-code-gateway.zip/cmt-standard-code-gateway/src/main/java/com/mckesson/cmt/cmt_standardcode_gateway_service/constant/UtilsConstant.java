package com.mckesson.cmt.cmt_standardcode_gateway_service.constant;

public class UtilsConstant {
    public static final String[] PROTECTED_ENDPOINTS = { "/standardcodes/**" };
}
