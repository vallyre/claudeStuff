package com.mckesson.cmt.cmt_standardcode_gateway_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmtStandardcodeGatewayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
